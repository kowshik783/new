#
#  _    _            _               _____           
# | |  | |          | |             |  __ \          
# | |__| | __ _  ___| | _____ _ __  | |__) | __ ___  
# |  __  |/ _` |/ __| |/ / _ \ '__| |  ___/ '__/ _ \ 
# | |  | | (_| | (__|   <  __/ |    | |   | | | (_) |
# |_|  |_|\__,_|\___|_|\_\___|_|    |_|   |_|  \___/ 
#          Hacking Tools by-Technical Dada

clear

sudo chmod +x /etc/

clear

sudo chmod +x /usr/share/doc

clear

sudo rm -rf /usr/share/doc/hackerpro/

clear

cd /etc/

clear

sudo rm -rf /etc/technicaldada

clear

mkdir technicaldada

clear

cd technicaldada

clear

git clone https://github.com/technicaldada/hackerpro.git

clear

cd hackerpro

clear

sudo chmod +x install.sh

clear

./install.sh

clear
